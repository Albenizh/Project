angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController', {
    url: '/page2',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.login', {
    url: '/page1',
    views: {
      'tab3': {
        templateUrl: 'templates/login.html',
        controller: 'loginCtrl'
      }
    }
  })

  .state('tabsController.tag', {
    url: '/page2',
    views: {
      'tab2': {
        templateUrl: 'templates/tag.html',
        controller: 'tagCtrl'
      }
    }
  })

  .state('tabsController.allDocs', {
    url: '/page4',
    views: {
      'tab2': {
        templateUrl: 'templates/allDocs.html',
        controller: 'allDocsCtrl'
      }
    }
  })

  .state('tabsController.unarchived', {
    url: '/page5',
    views: {
      'tab2': {
        templateUrl: 'templates/unarchived.html',
        controller: 'unarchivedCtrl'
      }
    }
  })

  .state('tabsController.sharedWithMe', {
    url: '/page6',
    views: {
      'tab2': {
        templateUrl: 'templates/sharedWithMe.html',
        controller: 'sharedWithMeCtrl'
      }
    }
  })

  .state('tabsController.camera', {
    url: '/page3',
    views: {
      'tab1': {
        templateUrl: 'templates/camera.html',
        controller: 'cameraCtrl'
      }
    }
  })

  .state('sync', {
    url: '/page7',
    templateUrl: 'templates/sync.html',
    controller: 'syncCtrl'
  })

  .state('scan', {
    url: '/page8',
    templateUrl: 'templates/scan.html',
    controller: 'scanCtrl'
  })

  .state('languages', {
    url: '/page9',
    templateUrl: 'templates/languages.html',
    controller: 'languagesCtrl'
  })

  .state('displayPDF', {
    url: '/page10',
    templateUrl: 'templates/displayPDF.html',
    controller: 'displayPDFCtrl'
  })

$urlRouterProvider.otherwise('/page2/page1')


});